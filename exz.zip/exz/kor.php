<!DOCTYPE html>
<html>
<head>
  <title>Корзина аптеки</title>
</head>
<body>
<h1>Корзина аптеки</h1>
  
  <table>
    <tr>
      <th>Название товара</th>
      <th>Цена</th>
      <th>Количество</th>
      <th>Действия</th>
    </tr>
    <tr>
      <td>Аптечный препарат 1</td>
      <td>100 руб.</td>
      <td>2</td>
      <td><button class="btn">Удалить</button></td>
    </tr>
    <tr>
      <td>Аптечный препарат 2</td>
      <td>200 руб.</td>
      <td>1</td>
      <td><button class="btn">Удалить</button></td>
    </tr>
  </table>
  <?php
    // Подключение к базе данных
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "apteka";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
      die("Ошибка подключения: " . $conn->connect_error);
    }

    // Получение данных из базы данных и вывод в таблицу
    $sql = "SELECT * FROM product";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      echo "<table>
              <tr>
                <th>Название товара</th>
                <th>Цена</th>
                <th>Количество</th>
                <th>Действия</th>
              </tr>";
      while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["name"] . "</td>
                <td>" . $row["price"] . "</td>
                <td>" . $row["quantity"] . "</td>
                <td><button class='btn'>Удалить</button></td>
              </tr>";
      }
      echo "</table>";
    } else {
      echo "Корзина пуста";
    }

    $conn->close();
  ?>

  <br>
  
  <a href="оплата.html" class="btn">Оформить заказ</a>
</body>
</html>
